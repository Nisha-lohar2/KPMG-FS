*&---------------------------------------------------------------------*
*& Report ZPP_RM_PM_DEFICIT_REPORT
*&---------------------------------------------------------------------*
*& WRICEF-ID 7 : Report for RM/PM Deficit based on FG Deficit
*&
*& Business Logic (per FS tab of
*& "WRICEF-ID 7 Report for RM PM deficit based on FG Deficit.xlsx"):
*&
*&   1. User enters Plant (mandatory). System derives the FG deficit
*&      using open Sales Order qty, open STO qty and FG stock:
*&        Deficit/Surplus = (Unrestricted Stock + Quality Stock
*&                            + In-Transit Stock)
*&                          - (Open Sales Order Qty + Open STO Qty)
*&   2. For every FG in deficit, explode the 1st level of the ACTIVE
*&      BOM (usage 1, application PP01, valid on system date) and
*&      calculate RM/PM requirement = BOM component qty * FG deficit
*&      qty.
*&   3. RM/PM Stock = Unrestricted + Quality stock, excluding storage
*&      locations flagged in custom table ZPP_PLAN_SLOC.
*&      RM/PM Deficit = RM/PM Stock - RM/PM Requirement.
*&   4. Work Center / PRT are read from the 1st routing found
*&      (MAPL -> PLKO -> PLAS -> PLPO -> CRHD / PLFH).
*&   5. Output is displayed via ALV.
*&
*& OPEN ITEMS (raised back to functional consultant - Mukesh Yadav -
*& not yet closed in the FS, implemented here as best-effort/TODO):
*&   a) "In-transit stock" is named in the deficit formula (BRD tab)
*&      but no source table/CDS view is defined anywhere in the FS.
*&      Implemented as a fully commented-out placeholder (see
*&      gv_in_transit_stock) so the formula structure is correct and
*&      can be wired up in one place once the source is confirmed.
*&   b) FS tab, cell A27 area contains QE01 control-sample / quality
*&      inspection configuration logic (TVARVC / ZQM_CONTROL_PLANT /
*&      ZQM_CONTROL_MTART / ZPP_QE01_CUST) that has no relationship
*&      to this RM/PM deficit report - it reads like it was pasted in
*&      from a different FS (QM control sample WRICEF). It has been
*&      deliberately EXCLUDED from this program. Please confirm with
*&      Mukesh whether that paragraph belongs to this spec at all.
*&---------------------------------------------------------------------*
REPORT zpp_rm_pm_deficit_report.

*---------------------------------------------------------------------*
* Type declarations
*---------------------------------------------------------------------*
TYPES: BEGIN OF ty_fg_deficit,
         matnr        TYPE matnr,          " Material (FG)
         maktx        TYPE maktx,          " Material description
         matkl        TYPE matkl,          " Material Group
         mvgr4_txt    TYPE bezei20,        " Material Category (4th sales spec grp text)
         werks        TYPE werks_d,        " Plant
         fg_stock     TYPE labst,          " FG Stock (unrestr. + quality [+ in-transit])
         total_so_qty TYPE kwmeng,         " Total open Sales Order qty
         net_sto_qty  TYPE bstmg,          " Net open STO qty
         deficit      TYPE menge_d,        " Deficit/Surplus FG (negative = deficit)
         ntgew        TYPE ntgew,          " Net weight
         gewei        TYPE gewei,          " Weight unit
       END OF ty_fg_deficit.

TYPES: BEGIN OF ty_alv,
         matnr       TYPE matnr,           " Material (FG)
         maktx       TYPE maktx,           " Material Description
         matkl       TYPE matkl,           " Material Group
         mvgr4_txt   TYPE bezei20,         " Material Category
         werks       TYPE werks_d,         " Plant
         fg_stock    TYPE labst,           " FG Stock
         total_so    TYPE kwmeng,          " Total Sales Order
         net_sto     TYPE bstmg,           " Net Total STO
         fg_deficit  TYPE menge_d,         " Deficit/Surplus FG
         idnrk       TYPE idnrk,           " BOM Component (RM/PM)
         comp_maktx  TYPE maktx,           " Component description
         menge_bom   TYPE menge_d,         " QTY as per BOM (component qty needed)
         meins_bom   TYPE meins,           " UoM
         rm_stock    TYPE labst,           " RM/PM Stock
         rm_deficit  TYPE menge_d,         " RM/PM Deficit
         minbe       TYPE minbe,           " Min Stock Level (Reorder point)
         bstma       TYPE bstma,           " Max Stock Level
         ntgew       TYPE ntgew,           " Net weight
         gewei       TYPE gewei,           " Weight unit
         arbpl       TYPE arbpl,           " Work Center
         prt_equnr   TYPE equnr,           " PRT (Equipment used as PRT)
       END OF ty_alv.

TYPES: BEGIN OF ty_sloc_excl,
         werks TYPE werks_d,
         lgort TYPE lgort_d,
       END OF ty_sloc_excl.

TYPES: BEGIN OF ty_so_calc,
         matnr    TYPE matnr,
         werks    TYPE werks_d,
         open_qty TYPE kwmeng,
       END OF ty_so_calc.

TYPES: BEGIN OF ty_sto_calc,
         matnr    TYPE matnr,
         werks    TYPE werks_d,
         open_qty TYPE bstmg,
       END OF ty_sto_calc.

TYPES: BEGIN OF ty_stock_calc,
         matnr TYPE matnr,
         werks TYPE werks_d,
         qty   TYPE labst,
       END OF ty_stock_calc.

*---------------------------------------------------------------------*
* Selection screen
*---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
SELECT-OPTIONS: s_werks FOR t001w-werks OBLIGATORY,      "Plant - Mandatory
                s_erdat FOR sy-datum,                    "Order Start Date - Optional
                s_matnr FOR mara-matnr.                  "Material Number - Optional
SELECTION-SCREEN END OF BLOCK b1.

AUTHORITY-CHECK OBJECT 'M_MSEG_WMB'
         ID 'WERKS' FIELD s_werks-low.

*---------------------------------------------------------------------*
* Global data
*---------------------------------------------------------------------*
DATA: gt_fg_deficit TYPE TABLE OF ty_fg_deficit,
      gt_alv        TYPE TABLE OF ty_alv,
      gt_sloc_excl  TYPE TABLE OF ty_sloc_excl,
      gt_fieldcat   TYPE lvc_t_fcat,
      gs_layout     TYPE lvc_s_layo.

* TODO (open item a): source for "in-transit stock" is not defined in
* the FS. Wire the read logic here once functional confirms the
* table/CDS view (e.g. stock in transfer STO, MB5T "Stock in Transit").
DATA: gv_in_transit_stock TYPE labst.

*---------------------------------------------------------------------*
* MAIN
*---------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM get_excluded_slocs.
  PERFORM get_fg_deficit.
  PERFORM explode_bom_and_get_rm_pm.
  PERFORM display_alv.

*&---------------------------------------------------------------------*
*&      Form  GET_EXCLUDED_SLOCS
*&      Read custom table ZPP_PLAN_SLOC : storage locations to be
*&      excluded from stock consideration (Plant + SLoc combination).
*&---------------------------------------------------------------------*
FORM get_excluded_slocs.
  SELECT werks lgort
    FROM zpp_plan_sloc
    INTO TABLE gt_sloc_excl
    WHERE werks IN s_werks.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_FG_DEFICIT
*&      Step 1 of FS: derive FG deficit = Total Stock - (Total SO qty
*&      + Net STO qty), plant/material wise.
*&---------------------------------------------------------------------*
FORM get_fg_deficit.

  DATA: ls_so       TYPE ty_so_calc,
        lt_so_calc  TYPE TABLE OF ty_so_calc,
        ls_sto      TYPE ty_sto_calc,
        lt_sto_calc TYPE TABLE OF ty_sto_calc.

*---------------------------------------------------------------------*
* 1a. Open Sales Order quantity
*     Order qty (VBAP) - delivered qty (LIPS, goods-issue posted),
*     for relevant item category TAN / doc category C, sales doc not
*     rejected, overall status not fully processed and not fully
*     delivery-blocked.
*---------------------------------------------------------------------*
  SELECT vbap~matnr, vbap~werks, vbap~vbeln, vbap~posnr, vbap~kwmeng
    FROM vbap
    INNER JOIN vbak ON vbak~vbeln = vbap~vbeln
    INTO TABLE @DATA(lt_vbap)
    WHERE vbap~werks     IN @s_werks
      AND vbap~matnr     IN @s_matnr
      AND vbap~pstyv     = 'TAN'
      AND vbap~abgru     = @space          " not rejected
      AND vbak~erdat     IN @s_erdat
      AND vbak~gbstk     <> 'C'.           " not fully completed

  IF lt_vbap IS NOT INITIAL.
    SELECT vbeln, posnr, lfimg
      FROM lips
      INTO TABLE @DATA(lt_lips)
      FOR ALL ENTRIES IN @lt_vbap
      WHERE vgbel = @lt_vbap-vbeln
        AND vgpos = @lt_vbap-posnr.
  ENDIF.

  LOOP AT lt_vbap INTO DATA(ls_vbap).
    DATA(lv_delivered) = 0.
    LOOP AT lt_lips INTO DATA(ls_lips)
        WHERE vgbel = ls_vbap-vbeln AND vgpos = ls_vbap-posnr.
      lv_delivered = lv_delivered + ls_lips-lfimg.
    ENDLOOP.

    COLLECT VALUE ty_so_calc( matnr = ls_vbap-matnr
                               werks = ls_vbap-werks
                               open_qty = ls_vbap-kwmeng - lv_delivered )
            INTO lt_so_calc.
  ENDLOOP.

*---------------------------------------------------------------------*
* 1b. Open STO (Stock Transport Order) quantity
*     Purchase order qty (EKPO) - GR quantity (EKBE, mvt 101/... via
*     goods receipt history), for STO doc types.
*---------------------------------------------------------------------*
  SELECT ekko~ebeln, ekpo~ebelp, ekpo~matnr, ekko~reswk AS werks,
         ekpo~menge
    FROM ekko
    INNER JOIN ekpo ON ekpo~ebeln = ekko~ebeln
    INTO TABLE @DATA(lt_ekpo)
    WHERE ekko~bsart IN ('ZUB','UB','ZSTR','ZOST','ZBST',
                          'ZUB1','ZUB2','ZUB3','ZUB4',
                          'ZUB5','ZUB6','ZUB7','ZUB8')
      AND ekko~reswk IN @s_werks
      AND ekpo~matnr IN @s_matnr
      AND ekpo~loekz = @space
      AND ekpo~elikz = @space.             " not completely delivered

  IF lt_ekpo IS NOT INITIAL.
    SELECT ebeln, ebelp, menge AS gr_menge
      FROM ekbe
      INTO TABLE @DATA(lt_ekbe)
      FOR ALL ENTRIES IN @lt_ekpo
      WHERE ebeln = @lt_ekpo-ebeln
        AND ebelp = @lt_ekpo-ebelp
        AND vgabe = '1'.                   " goods receipt
  ENDIF.

  LOOP AT lt_ekpo INTO DATA(ls_ekpo).
    DATA(lv_gr_qty) = 0.
    LOOP AT lt_ekbe INTO DATA(ls_ekbe)
        WHERE ebeln = ls_ekpo-ebeln AND ebelp = ls_ekpo-ebelp.
      lv_gr_qty = lv_gr_qty + ls_ekbe-gr_menge.
    ENDLOOP.

    COLLECT VALUE ty_sto_calc( matnr = ls_ekpo-matnr
                                werks = ls_ekpo-werks
                                open_qty = ls_ekpo-menge - lv_gr_qty )
            INTO lt_sto_calc.
  ENDLOOP.

*---------------------------------------------------------------------*
* 1c. FG Stock (Unrestricted + Quality), excluding ZPP_PLAN_SLOC
*     storage locations. Split batch-managed (MCHB) vs
*     non-batch-managed (MARD) per FS "Condition 1/2/3" logic.
*---------------------------------------------------------------------*
  SELECT matnr, werks, lgort, clabs, cinsm
    FROM mchb
    INTO TABLE @DATA(lt_mchb)
    WHERE werks IN @s_werks
      AND matnr IN @s_matnr.

  SELECT matnr, werks, lgort, labst, insme
    FROM mard
    INTO TABLE @DATA(lt_mard)
    WHERE werks IN @s_werks
      AND matnr IN @s_matnr.

  DATA: ls_stock      TYPE ty_stock_calc,
        lt_stock_calc TYPE TABLE OF ty_stock_calc.

  LOOP AT lt_mchb INTO DATA(ls_mchb)
      WHERE NOT ( werks, lgort ) IN gt_sloc_excl.
    COLLECT VALUE ty_stock_calc( matnr = ls_mchb-matnr
                                  werks = ls_mchb-werks
                                  qty   = ls_mchb-clabs + ls_mchb-cinsm )
            INTO lt_stock_calc.
  ENDLOOP.

  LOOP AT lt_mard INTO DATA(ls_mard)
      WHERE NOT ( werks, lgort ) IN gt_sloc_excl.
    " avoid double counting materials already summed via MCHB (batch-managed)
    READ TABLE lt_mchb TRANSPORTING NO FIELDS
         WITH KEY matnr = ls_mard-matnr werks = ls_mard-werks.
    IF sy-subrc <> 0.
      COLLECT VALUE ty_stock_calc( matnr = ls_mard-matnr
                                    werks = ls_mard-werks
                                    qty   = ls_mard-labst + ls_mard-insme )
              INTO lt_stock_calc.
    ENDIF.
  ENDLOOP.

*---------------------------------------------------------------------*
* 1d. Combine: Deficit/Surplus = Total Stock - (Total SO + Net STO)
*     (+ In-Transit Stock once source is confirmed - see open item a)
*---------------------------------------------------------------------*
  LOOP AT lt_stock_calc INTO ls_stock.
    DATA(ls_fg) = VALUE ty_fg_deficit( matnr = ls_stock-matnr
                                        werks = ls_stock-werks
                                        fg_stock = ls_stock-qty ).

    READ TABLE lt_so_calc INTO ls_so
         WITH KEY matnr = ls_stock-matnr werks = ls_stock-werks.
    IF sy-subrc = 0.
      ls_fg-total_so_qty = ls_so-open_qty.
    ENDIF.

    READ TABLE lt_sto_calc INTO ls_sto
         WITH KEY matnr = ls_stock-matnr werks = ls_stock-werks.
    IF sy-subrc = 0.
      ls_fg-net_sto_qty = ls_sto-open_qty.
    ENDIF.

    " Deficit/Surplus FG = Total Stock - (Total SO + Net STO)
    " gv_in_transit_stock intentionally not added - see open item (a)
    ls_fg-deficit = ls_fg-fg_stock - ( ls_fg-total_so_qty + ls_fg-net_sto_qty ).

    " enrich master data: description, material group, category, weight
    SELECT SINGLE maktx FROM makt INTO ls_fg-maktx
      WHERE matnr = ls_fg-matnr AND spras = sy-langu.
    SELECT SINGLE matkl, ntgew, gewei FROM mara
      INTO (ls_fg-matkl, ls_fg-ntgew, ls_fg-gewei)
      WHERE matnr = ls_fg-matnr.

    SELECT SINGLE mvgr4 FROM mvke INTO @DATA(lv_mvgr4)
      WHERE matnr = @ls_fg-matnr.
    IF lv_mvgr4 IS NOT INITIAL.
      SELECT SINGLE bezei FROM tvm4t INTO ls_fg-mvgr4_txt
        WHERE mvgr4 = lv_mvgr4 AND spras = sy-langu.
    ENDIF.

    " Only materials in deficit (negative) are relevant to explode further
    IF ls_fg-deficit < 0.
      APPEND ls_fg TO gt_fg_deficit.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  EXPLODE_BOM_AND_GET_RM_PM
*&      Step 2/3 of FS: explode 1 level of active BOM for each FG in
*&      deficit, and derive RM/PM stock/deficit for each component.
*&---------------------------------------------------------------------*
FORM explode_bom_and_get_rm_pm.

  DATA: lt_stb        TYPE TABLE OF stpox,
        lt_matcat      TYPE TABLE OF cscmat,
        ls_bom_header TYPE cstmat,
        lv_deficit_qty TYPE menge_d.

  LOOP AT gt_fg_deficit INTO DATA(ls_fg).

    " Deficit is negative; requirement to explode = absolute value
    lv_deficit_qty = abs( ls_fg-deficit ).

    CLEAR lt_stb.
    CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
      EXPORTING
        capid                 = 'PP01'
        datuv                 = sy-datum
        emeng                 = lv_deficit_qty
        mehrs                 = 'X'
        mtnrv                 = ls_fg-matnr
        stpst                 = 0
        werks                 = ls_fg-werks
        mmory                 = 1              " 1st level explosion only
      IMPORTING
        topmat                = ls_bom_header
      TABLES
        stb                   = lt_stb
      EXCEPTIONS
        alt_not_found         = 1
        call_invalid          = 2
        material_not_found    = 3
        missing_authorization = 4
        no_bom_found          = 5
        no_plant_data         = 6
        no_suitable_bom_found = 7
        conversion_error      = 8
        OTHERS                = 9.

    IF sy-subrc <> 0.
      " no active BOM found for this FG / plant - skip, keep FG line
      " visible with blank component info
      APPEND VALUE ty_alv( matnr      = ls_fg-matnr
                            maktx      = ls_fg-maktx
                            matkl      = ls_fg-matkl
                            mvgr4_txt  = ls_fg-mvgr4_txt
                            werks      = ls_fg-werks
                            fg_stock   = ls_fg-fg_stock
                            total_so   = ls_fg-total_so_qty
                            net_sto    = ls_fg-net_sto_qty
                            fg_deficit = ls_fg-deficit
                            ntgew      = ls_fg-ntgew
                            gewei      = ls_fg-gewei ) TO gt_alv.
      CONTINUE.
    ENDIF.

    " only direct (1st level) component items, materials only (STPO type L)
    LOOP AT lt_stb INTO DATA(ls_stb) WHERE stufe = 1 AND typps = 'L'.

      DATA(ls_alv) = VALUE ty_alv(
                        matnr      = ls_fg-matnr
                        maktx      = ls_fg-maktx
                        matkl      = ls_fg-matkl
                        mvgr4_txt  = ls_fg-mvgr4_txt
                        werks      = ls_fg-werks
                        fg_stock   = ls_fg-fg_stock
                        total_so   = ls_fg-total_so_qty
                        net_sto    = ls_fg-net_sto_qty
                        fg_deficit = ls_fg-deficit
                        idnrk      = ls_stb-idnrk
                        menge_bom  = ls_stb-mngko    " qty as per BOM explosion
                        meins_bom  = ls_stb-meins
                        ntgew      = ls_fg-ntgew
                        gewei      = ls_fg-gewei ).

      SELECT SINGLE maktx FROM makt INTO ls_alv-comp_maktx
        WHERE matnr = ls_stb-idnrk AND spras = sy-langu.

      " RM/PM Stock (unrestricted + quality), excluding ZPP_PLAN_SLOC
      DATA(lv_rm_stock) = 0.
      SELECT matnr, werks, lgort, clabs, cinsm
        FROM mchb
        INTO TABLE @DATA(lt_mchb_rm)
        WHERE matnr = @ls_stb-idnrk
          AND werks = @ls_fg-werks.

      IF lt_mchb_rm IS NOT INITIAL.
        LOOP AT lt_mchb_rm INTO DATA(ls_mchb_rm)
            WHERE NOT ( werks, lgort ) IN gt_sloc_excl.
          lv_rm_stock = lv_rm_stock + ls_mchb_rm-clabs + ls_mchb_rm-cinsm.
        ENDLOOP.
      ELSE.
        SELECT matnr, werks, lgort, labst, insme
          FROM mard
          INTO TABLE @DATA(lt_mard_rm)
          WHERE matnr = @ls_stb-idnrk
            AND werks = @ls_fg-werks.
        LOOP AT lt_mard_rm INTO DATA(ls_mard_rm)
            WHERE NOT ( werks, lgort ) IN gt_sloc_excl.
          lv_rm_stock = lv_rm_stock + ls_mard_rm-labst + ls_mard_rm-insme.
        ENDLOOP.
      ENDIF.

      ls_alv-rm_stock = lv_rm_stock.
      " RM/PM Deficit = RM/PM Stock - Requirement Qty (BOM explosion qty)
      ls_alv-rm_deficit = lv_rm_stock - ls_stb-mngko.

      " Min/Max stock level (MARC - reorder point / max stock)
      SELECT SINGLE minbe, bstma FROM marc
        INTO (ls_alv-minbe, ls_alv-bstma)
        WHERE matnr = ls_stb-idnrk AND werks = ls_fg-werks.

      APPEND ls_alv TO gt_alv.
    ENDLOOP.

    " Work Center / PRT from 1st routing found (only once per FG)
    PERFORM get_work_center_and_prt USING ls_fg-matnr ls_fg-werks
                                     CHANGING gt_alv.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_WORK_CENTER_AND_PRT
*&      FS: "If multiple routing exist with PRT, fetch Work Center and
*&      PRT from the 1st routing only."
*&---------------------------------------------------------------------*
FORM get_work_center_and_prt USING pv_matnr TYPE matnr
                                    pv_werks TYPE werks_d
                              CHANGING ct_alv TYPE TABLE OF ty_alv.

  DATA: lv_arbpl  TYPE arbpl,
        lv_equnr  TYPE equnr.

  SELECT SINGLE plnnr, plnal FROM mapl INTO @DATA(ls_mapl)
    WHERE matnr = @pv_matnr
      AND werks = @pv_werks
      AND plnty IN ( 'N', '2' ).
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  SELECT SINGLE plnnr FROM plko INTO @DATA(lv_plnnr_ko)
    WHERE plnty = 'N'
      AND plnnr = @ls_mapl-plnnr
      AND plnal = @ls_mapl-plnal
      AND loekz = @space.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  SELECT plnnr, zaehl UP TO 1 ROWS FROM plas
    INTO TABLE @DATA(lt_plas)
    WHERE plnnr = @ls_mapl-plnnr
      AND plnal = @ls_mapl-plnal
    ORDER BY zaehl.

  IF lt_plas IS NOT INITIAL.
    READ TABLE lt_plas INTO DATA(ls_plas) INDEX 1.
    SELECT SINGLE arbid FROM plpo INTO @DATA(lv_arbid)
      WHERE plnnr = @ls_plas-plnnr AND zaehl = @ls_plas-zaehl.
    IF sy-subrc = 0.
      SELECT SINGLE arbpl FROM crhd INTO lv_arbpl
        WHERE objid = lv_arbid.
    ENDIF.
  ENDIF.

  " PRT (production resource/tool) via PLFH
  SELECT SINGLE objid FROM plfh INTO @DATA(lv_objid)
    WHERE plnnr = @ls_mapl-plnnr
      AND plnal = @ls_mapl-plnal
      AND loekz = @space.
  IF sy-subrc = 0.
    SELECT SINGLE equnr FROM crve_a INTO lv_equnr
      WHERE objid = lv_objid AND objty = 'FH'.
  ENDIF.

  LOOP AT ct_alv ASSIGNING FIELD-SYMBOL(<fs_alv>)
      WHERE matnr = pv_matnr AND werks = pv_werks.
    <fs_alv>-arbpl     = lv_arbpl.
    <fs_alv>-prt_equnr = lv_equnr.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
FORM display_alv.

  DATA: lo_alv TYPE REF TO cl_salv_table.

  IF gt_alv IS INITIAL.
    MESSAGE 'No FG deficit found for the given selection.' TYPE 'S'
            DISPLAY LIKE 'I'.
    RETURN.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_alv ).

      lo_alv->get_functions( )->set_all( abap_true ).
      lo_alv->get_columns( )->set_optimize( abap_true ).

      DATA(lo_columns) = lo_alv->get_columns( ).
      lo_columns->get_column( 'MATNR' )->set_short_text( 'Material' ).
      lo_columns->get_column( 'MAKTX' )->set_short_text( 'Mat.Desc' ).
      lo_columns->get_column( 'MATKL' )->set_short_text( 'Mat.Grp' ).
      lo_columns->get_column( 'MVGR4_TXT' )->set_short_text( 'Category' ).
      lo_columns->get_column( 'WERKS' )->set_short_text( 'Plant' ).
      lo_columns->get_column( 'FG_STOCK' )->set_short_text( 'FG Stock' ).
      lo_columns->get_column( 'TOTAL_SO' )->set_short_text( 'Tot.SO' ).
      lo_columns->get_column( 'NET_STO' )->set_short_text( 'Net STO' ).
      lo_columns->get_column( 'FG_DEFICIT' )->set_short_text( 'FG Def/Sur' ).
      lo_columns->get_column( 'IDNRK' )->set_short_text( 'Component' ).
      lo_columns->get_column( 'COMP_MAKTX' )->set_short_text( 'Comp.Desc' ).
      lo_columns->get_column( 'MENGE_BOM' )->set_short_text( 'BOM Qty' ).
      lo_columns->get_column( 'RM_STOCK' )->set_short_text( 'RM/PM Stk' ).
      lo_columns->get_column( 'RM_DEFICIT' )->set_short_text( 'RM/PM Def' ).
      lo_columns->get_column( 'MINBE' )->set_short_text( 'Min Stk' ).
      lo_columns->get_column( 'BSTMA' )->set_short_text( 'Max Stk' ).
      lo_columns->get_column( 'NTGEW' )->set_short_text( 'Net Wt' ).
      lo_columns->get_column( 'ARBPL' )->set_short_text( 'Work Ctr' ).
      lo_columns->get_column( 'PRT_EQUNR' )->set_short_text( 'PRT' ).

      lo_alv->display( ).

    CATCH cx_salv_msg INTO DATA(lx_salv_msg).
      MESSAGE lx_salv_msg->get_text( ) TYPE 'E'.
  ENDTRY.

ENDFORM.
