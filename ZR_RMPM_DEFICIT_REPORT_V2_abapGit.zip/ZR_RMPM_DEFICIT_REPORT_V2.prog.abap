*&---------------------------------------------------------------------*
*& Report ZR_RMPM_DEFICIT_REPORT_V2
*&---------------------------------------------------------------------*
*& WRICEF-ID 7 — Report for BOM explosion based on FG deficit
*& Module      : PP
*& Object Type : Report
*& Source      : Functional Specification, "Detailed FS" sheet, v1
*& Owner       : Mukesh Yadav (Functional)
*&
*& Rebuilt against the field-level source mapping in the Detailed FS
*& sheet. This supersedes the earlier draft, which used MARA/MTART and
*& MAST/STKO as placeholders before the field-level FS was available.
*& Table/CDS view names below are taken verbatim from that sheet.
*&
*& PACKAGING (this revision): repackaged as a single abapGit PROG
*& object (.prog.abap + .prog.xml + package.devc.xml + .abapgit.xml),
*& matching the layout of the ZPP_OEE_ADHESIVE_REPORT reference package
*& — one flat program, no separate includes, with selection-screen text
*& symbols carried in the .prog.xml's TPOOL so they import automatically
*& instead of needing manual maintenance via SE38 afterward.
*&
*& FIX (older revision): a CHANGING parameter was once declared as an
*& inline anonymous table type ("... TYPE STANDARD TABLE OF ty_x"),
*& which is not valid in a FORM interface (only valid in TYPES/DATA
*& statements) — that caused a formal/actual parameter count mismatch
*& at syntax-check time. Fixed by declaring named table types and using
*& those in every FORM signature instead. The same rule applies to
*& inline VALUE literals of a keyed table type (e.g. "VALUE SORTED
*& TABLE OF x( WITH UNIQUE KEY y ( ) )") — also invalid; every keyed
*& work table below is declared via a classic DATA statement instead,
*& with inline declarations reserved for LOOP/READ TABLE/SELECT targets
*& and for tables of an already-named type.
*&
*& OPTIMIZATION (this revision — full pass): every SELECT-in-LOOP in
*& the report has been replaced with a bulk fetch done once, with
*& in-memory lookups (READ TABLE on sorted/unique-keyed tables) inside
*& the loops:
*&   - Stage A used to issue 2-4 SELECT SINGLEs per FG candidate
*&     (description, group, category) — now 3-4 bulk selects total
*&     (GET_MATERIAL_MASTER_DATA_BULK).
*&   - Stages B/C/D used to be bulk *within* one FG, but were invoked
*&     once per FG from the main LOOP — i.e. still O(N) round trips
*&     for N FG candidates. Now each stage runs once for the WHOLE
*&     selection (STAGE_B/C/D_...).
*&   - Stage F's BOM-alternative lookup used to run 2 SELECTs per
*&     deficit FG — now 2 bulk selects total for all deficit FGs
*&     (GET_ACTIVE_BOM_ALTERNATIVES_BULK).
*&   - Stage G (the worst offender) used to run up to ~8 SELECT
*&     statements PER BOM COMPONENT, across every deficit FG's
*&     exploded BOM. Now GET_STOCK_BULK, GET_MINMAX_STOCK_BULK,
*&     GET_NET_WEIGHT_BULK, and GET_WORKCENTER_PRT_BULK each run a
*&     fixed, small number of SELECTs regardless of how many
*&     components/FGs are involved, then STAGE_G_PROCESS_COMPONENTS_
*&     BULK's final assembly LOOP does pure in-memory table reads.
*& The one exception is CS_BOM_EXPL_MAT_V2 (Stage F's actual BOM
*& explosion, in EXPLODE_BOM): it is a function module, not a raw
*& SELECT, and the FS explicitly requires per-material explosion ("at
*& a time one BOM will be considered"), so it necessarily still runs
*& once per deficit FG inside a loop — that loop contains no SELECT
*& statements, only the FM call.
*& Behaviour/output is unchanged — same filters, same formulas, only
*& the number of DB round trips and the coding style are different.
*&
*& OPEN ITEMS — confirm with Mukesh Yadav before this goes to test:
*&   1) BRD text includes "In transit stock" in the deficit formula,
*&      but the Detailed FS's own formula step ("Total stock -
*&      (Total SO qty + Net STO)") does not use it, and no source
*&      table is given anywhere in the sheet for in-transit stock.
*&      NOT implemented — see the Stage E calculation below.
*&   2) FG candidate list is driven entirely from open Sales Order
*&      items (I_SalesDocumentItem, ITEMCATEGORY=TAN, DOCCATEGORY=C).
*&      An FG with a deficit driven only by STO and zero open sales
*&      orders in the plant will NOT appear on this report. Confirm
*&      this is intended — see STAGE_A_BUILD_FG_CANDIDATES.
*&   3) BOM alternative: FS says take BillOfMaterial/Variant combos
*&      from I_BillOfMaterialItemTp, filtered active via
*&      I_BillOfMaterial (not archived, status = 1), but does not
*&      state a tie-breaker if more than one active alternative
*&      remains. Implemented as lowest BillOfMaterialVariant — see
*&      GET_ACTIVE_BOM_ALTERNATIVES_BULK, confirm the tie-break rule.
*&      The same "first routing" tie-break is reused for Work
*&      Center/PRT (lowest PLNNR, then lowest ZAEHL).
*&   4) Net Total STO delivery-status filter: FS text says
*&      "GOODSMOVEMENTSTATUS=C and OVERALL STATUS=A and B" in the same
*&      sentence. Implemented as GoodsMovementStatus = 'C' AND
*&      SdProcessStatus IN ('A','B') — that combination is unusual (A
*&      commonly means "not yet processed"). Confirm the intended
*&      status codes and the exact field name with Mukesh — see
*&      STAGE_D_GET_NET_TOTAL_STO_QTY.
*&   5) Order Start Date: FS selection-screen table names the field
*&      "Order date from/to" but never states the underlying source.
*&      Wired to I_SalesDocumentItem-CreationDate (item-level creation
*&      date) as the closest CDS equivalent of the classic VBAP-ERDAT
*&      field. Confirm this is the field the business means — see
*&      STAGE_A_BUILD_FG_CANDIDATES.
*&   6) Total Sales Order (Stage C): the Detailed FS's own text for
*&      this step reads "...to I_DELIVERYDOCUMENTITEM- REFERENCESD-
*&      DOCUMENT and REFERENCESDDOCUMENTITEM for
*&      I_DELIVERYDOCUMENTITEM=A and B and GOODSMOVEMENTSTATUS is not
*&      equal to C..." — the "=A and B" clause does not name a field
*&      (likely a delivery item category filter), so it cannot be
*&      implemented as written. STAGE_C_GET_TOTAL_SO_QTY currently
*&      filters only on GoodsMovementStatus <> 'C'. Confirm what
*&      "=A and B" was meant to filter.
*&   7) Net Total STO (Stage D): Detailed FS text says to take
*&      "PURCHASEORDER and PURCHASEORDERITEM, MANUFACTURERMATERIAL,
*&      ORDERQUANTITY" from I_PurchaseOrderItem — i.e. it names
*&      MANUFACTURERMATERIAL as the field carrying the material. The
*&      report instead filters/matches on I_PurchaseOrderItem-Material
*&      (the FG being processed), since ManufacturerMaterial is
*&      normally populated for external-vendor cross-references, not
*&      intra-company STOs, and matching on it would silently drop
*&      valid STO lines. Confirm which field should actually drive the
*&      match.
*&   8) I_PurchaseOrderHistory is listed in the FS's "Selection
*&      Parameters" table (#9) as a source object, but the field-level
*&      Detailed FS steps for Net Total STO explicitly route delivered
*&      quantity through I_DeliveryDocumentItem instead. Implemented
*&      per the field-level steps; the listed-but-unused
*&      I_PurchaseOrderHistory reference is flagged here in case it
*&      was meant to replace/supplement that source.
*&   9) Authorization object — BRD only says "Plant as an
*&      authorization object", no object name given. Used M_MSEG_WWA
*&      as a placeholder in AUTHORITY_CHECK_PLANT. Needs confirmation
*&      from Basis/Security on the correct object.
*&
*& Not yet syntax-checked / unit-tested against a live system - run
*& ATC and SE38 syntax check before transport.
*&---------------------------------------------------------------------*
REPORT zr_rmpm_deficit_report_v2.

*----------------------------------------------------------------------*
* Custom table ZPP_PLAN_SLOC (WERKS, LGORT) — assumed to already exist
* per Section 7 of the earlier technical spec / "Assumption" row of BRD
* ("Few of the SLoc stock should not be considered").
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Global TYPES and DATA
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_fg_deficit,
         matnr        TYPE matnr,        "FG material (Product)
         werks        TYPE werks_d,
         maktx        TYPE maktx,
         matkl        TYPE matkl,        "Material Group (ProductGroup)
         mvgr4_txt    TYPE bezei20,      "Material Category
         fg_stock     TYPE menge_d,      "Total Stock (Unrestr. + Quality)
         tot_so_qty   TYPE menge_d,
         net_sto_qty  TYPE menge_d,
         deficit_fg   TYPE menge_d,      "negative = shortage
       END OF ty_fg_deficit.

TYPES: BEGIN OF ty_bom_comp.
         INCLUDE TYPE ty_fg_deficit AS fg. "originating FG header
TYPES:   idnrk        TYPE idnrk,        "component material
         menge        TYPE menge_d,      "MNGKO from BOM explosion
       END OF ty_bom_comp.

TYPES: tt_bom_comp TYPE STANDARD TABLE OF ty_bom_comp WITH EMPTY KEY.

TYPES: BEGIN OF ty_alv_out.
         INCLUDE TYPE ty_fg_deficit AS fg.
TYPES:   idnrk        TYPE idnrk,        "BOM Component
         qty_bom      TYPE menge_d,      "QTY as per BOM
         rmpm_stock   TYPE menge_d,      "component Stock
         rmpm_deficit TYPE menge_d,      "component Deficit
         min_stock    TYPE menge_d,
         max_stock    TYPE menge_d,
         net_weight   TYPE ntgew,
         arbpl        TYPE arbpl,        "Work Center
         equnr        TYPE equnr,        "PRT
       END OF ty_alv_out.

TYPES: BEGIN OF ty_so_item,
         salesdocument     TYPE vbeln,
         salesdocumentitem TYPE posnr,
         matnr             TYPE matnr,
         werks             TYPE werks_d,
         orderquantity     TYPE menge_d,
       END OF ty_so_item,
       tt_so_item TYPE STANDARD TABLE OF ty_so_item WITH EMPTY KEY.

TYPES: BEGIN OF ty_sloc_excl,
         werks TYPE werks_d,
         lgort TYPE lgort_d,
       END OF ty_sloc_excl.

* ---- Generic (Material, Plant) key/result tables shared by the bulk
*      forms below. IDNRK and MATNR share the same underlying type, so
*      these are reused for both FG-level and component-level lookups.
TYPES: BEGIN OF ty_matnr_werks,
         matnr TYPE matnr,
         werks TYPE werks_d,
       END OF ty_matnr_werks,
       tt_matnr_werks TYPE SORTED TABLE OF ty_matnr_werks
                          WITH UNIQUE KEY matnr werks.

TYPES: BEGIN OF ty_matnr_werks_qty,
         matnr TYPE matnr,
         werks TYPE werks_d,
         qty   TYPE menge_d,
       END OF ty_matnr_werks_qty,
       tt_matnr_werks_qty TYPE SORTED TABLE OF ty_matnr_werks_qty
                              WITH UNIQUE KEY matnr werks.

TYPES: BEGIN OF ty_matnr_werks_stlal,
         matnr TYPE matnr,
         werks TYPE werks_d,
         stlal TYPE stlal,
       END OF ty_matnr_werks_stlal,
       tt_matnr_werks_stlal TYPE SORTED TABLE OF ty_matnr_werks_stlal
                                WITH UNIQUE KEY matnr werks.

TYPES: BEGIN OF ty_minmax_result,
         matnr     TYPE matnr,
         werks     TYPE werks_d,
         min_stock TYPE menge_d,
         max_stock TYPE menge_d,
       END OF ty_minmax_result,
       tt_minmax_result TYPE SORTED TABLE OF ty_minmax_result
                            WITH UNIQUE KEY matnr werks.

TYPES: BEGIN OF ty_netweight_result,
         matnr      TYPE matnr,
         net_weight TYPE ntgew,
       END OF ty_netweight_result,
       tt_netweight_result TYPE SORTED TABLE OF ty_netweight_result
                               WITH UNIQUE KEY matnr.

TYPES: BEGIN OF ty_wc_result,
         matnr TYPE matnr,
         werks TYPE werks_d,
         arbpl TYPE arbpl,
       END OF ty_wc_result,
       tt_wc_result TYPE SORTED TABLE OF ty_wc_result
                        WITH UNIQUE KEY matnr werks.

TYPES: BEGIN OF ty_prt_result,
         matnr TYPE matnr,
         werks TYPE werks_d,
         equnr TYPE equnr,
       END OF ty_prt_result,
       tt_prt_result TYPE SORTED TABLE OF ty_prt_result
                         WITH UNIQUE KEY matnr werks.

DATA: gt_fg_candidates TYPE STANDARD TABLE OF ty_fg_deficit WITH EMPTY KEY,
      gt_bom_comp      TYPE tt_bom_comp,
      gt_alv_out       TYPE STANDARD TABLE OF ty_alv_out    WITH EMPTY KEY,
      gt_so_items_raw  TYPE tt_so_item,
      gt_sloc_excl     TYPE SORTED TABLE OF ty_sloc_excl
                          WITH NON-UNIQUE KEY werks lgort.

* ---- Dummy typed objects for SELECT-OPTIONS ... FOR, so the
*      selection screen doesn't need a classic TABLES work area.
DATA: gv_werks_dummy TYPE werks_d,
      gv_matnr_dummy TYPE matnr.

*&---------------------------------------------------------------------*
*& Selection Screen — Plant mandatory, Order Date + Material optional
*& (all as ranges, per BRD "Selection Screen" table: From/To on each)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
SELECT-OPTIONS: s_werks FOR gv_werks_dummy OBLIGATORY,
                s_erdat FOR sy-datum,
                s_matnr FOR gv_matnr_dummy.
SELECTION-SCREEN END OF BLOCK b1.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements if not carried
*& by the abapGit import's .prog.xml TPOOL):
*&   001 Selection Screen
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Main processing — every PERFORM below runs a fixed, small number of
*& SELECTs regardless of how many FGs/components are involved; none of
*& them are called from inside a data-dependent LOOP.
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  PERFORM authority_check_plant.
  PERFORM load_sloc_exclusions.

  PERFORM stage_a_build_fg_candidates.

  PERFORM stage_b_get_fg_stock.
  PERFORM stage_c_get_total_so_qty.
  PERFORM stage_d_get_net_total_sto_qty.

  " Stage E — Deficit/Surplus = Total stock - (Total SO qty + Net STO)
  " NOTE: in-transit stock deliberately omitted — see header, open
  " item 1. In-memory only, no DB access — fine inside a LOOP.
  LOOP AT gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fg>).
    <fg>-deficit_fg = <fg>-fg_stock - ( <fg>-tot_so_qty + <fg>-net_sto_qty ).
  ENDLOOP.

  " Stage F — BOM explosion (deficit FGs only, 1st active alternative)
  PERFORM stage_f_bom_explosion_all.

  " Stage G — per BOM component, bulk-enriched
  PERFORM stage_g_process_components_bulk.

  PERFORM display_alv.

*&---------------------------------------------------------------------*
*&      Form  AUTHORITY_CHECK_PLANT
*&---------------------------------------------------------------------*
* BRD: "Plant as an authorization object". Placeholder object below —
* confirm the correct authorization object with Basis/Security.
* Not a SELECT — AUTHORITY-CHECK is a native statement, not something
* that can be bulked, so this stays as one check per plant range line.
*&---------------------------------------------------------------------*
FORM authority_check_plant.

  LOOP AT s_werks INTO DATA(ls_werks).
    AUTHORITY-CHECK OBJECT 'M_MSEG_WWA'
      ID 'WERKS' FIELD ls_werks-low
      ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE e172(00) WITH ls_werks-low. "No authorization for plant &1
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  LOAD_SLOC_EXCLUSIONS
*&---------------------------------------------------------------------*
FORM load_sloc_exclusions.

  SELECT werks, lgort
    FROM zpp_plan_sloc
    INTO TABLE @gt_sloc_excl.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_A_BUILD_FG_CANDIDATES
*&---------------------------------------------------------------------*
* Detailed FS, "Material" row:
*   Pass selection screen plant to I_SalesDocumentItem-PLANT for
*   SALESDOCUMENTITEMCATEGORY = 'TAN' and SDDOCUMENTCATEGORY = 'C',
*   take PRODUCT. Also filtered by SalesDocumentRjcnReason = '' up
*   front since Stage C re-reads the same base condition anyway.
* S_ERDAT (BRD "Order Start date") applied against Creationdate — see
* header, open item 5, the FS never names the underlying date field.
*&---------------------------------------------------------------------*
FORM stage_a_build_fg_candidates.

  SELECT sdi~salesdocument, sdi~salesdocumentitem,
         sdi~product AS matnr, sdi~plant AS werks,
         sdi~orderquantity
    FROM i_salesdocumentitem AS sdi
    INTO TABLE @gt_so_items_raw
    WHERE sdi~plant                     IN @s_werks
      AND sdi~product                   IN @s_matnr
      AND sdi~creationdate              IN @s_erdat
      AND sdi~salesdocumentitemcategory  = 'TAN'
      AND sdi~sddocumentcategory         = 'C'
      AND sdi~salesdocumentrjcnreason    = ''.

  " Distinct Product/Plant -> FG candidate list
  DATA(lt_distinct) = gt_so_items_raw.
  SORT lt_distinct BY matnr werks.
  DELETE ADJACENT DUPLICATES FROM lt_distinct COMPARING matnr werks.

  LOOP AT lt_distinct INTO DATA(ls_distinct).
    APPEND INITIAL LINE TO gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fs_fg>).
    <fs_fg>-matnr = ls_distinct-matnr.
    <fs_fg>-werks = ls_distinct-werks.
  ENDLOOP.

  PERFORM get_material_master_data_bulk.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_MATERIAL_MASTER_DATA_BULK
*&---------------------------------------------------------------------*
* Bulk-fetches Description/Group/Category for every distinct FG
* candidate in 3-4 round trips total, instead of 2-4 SELECT SINGLEs
* per FG inside a LOOP.
*   Description : I_SalesDocumentItem-Product -> I_ProductText-Product,
*                 PRODUCTNAME for LANGUAGE = 'E'.
*   Group       : I_SalesDocumentItem-Product -> I_Product-Product,
*                 PRODUCTGROUP.
*   Category    : I_SalesDocumentItem-Product ->
*                 I_ProductSalesDelivery-Product where
*                 FOURTHSALESSPECPRODUCTGROUP is not blank, then that
*                 value -> TVM4T-MVGR4 for SPRAS='E', take BEZEI.
*&---------------------------------------------------------------------*
FORM get_material_master_data_bulk.

  TYPES: BEGIN OF ty_matnr_key,
           matnr TYPE matnr,
         END OF ty_matnr_key.
  TYPES: BEGIN OF ty_mvgr4_raw,
           matnr TYPE matnr,
           mvgr4 TYPE mvgr4,
         END OF ty_mvgr4_raw.

  " Ad-hoc keyed work tables: declared explicitly (not via inline VALUE)
  " because an anonymous table type with a WITH KEY clause is only
  " valid in a TYPES/DATA statement, not as an inline operand — see the
  " header note on the original STAGE_F_BOM_EXPLOSION bug.
  DATA: lt_matnr      TYPE SORTED TABLE OF ty_matnr_key WITH UNIQUE KEY matnr,
        lt_mvgr4_keys TYPE SORTED TABLE OF ty_mvgr4_raw WITH UNIQUE KEY mvgr4.

  LOOP AT gt_fg_candidates INTO DATA(ls_fg).
    INSERT VALUE ty_matnr_key( matnr = ls_fg-matnr ) INTO TABLE lt_matnr.
  ENDLOOP.

  IF lt_matnr IS INITIAL.
    RETURN.
  ENDIF.

  SELECT product AS matnr, productname AS maktx
    FROM i_producttext
    INTO TABLE @DATA(lt_maktx)
    FOR ALL ENTRIES IN @lt_matnr
    WHERE product  = @lt_matnr-matnr
      AND language = 'E'.

  SELECT product AS matnr, productgroup AS matkl
    FROM i_product
    INTO TABLE @DATA(lt_matkl)
    FOR ALL ENTRIES IN @lt_matnr
    WHERE product = @lt_matnr-matnr.

  SELECT product AS matnr, fourthsalesspecproductgroup AS mvgr4
    FROM i_productsalesdelivery
    INTO TABLE @DATA(lt_mvgr4_raw)
    FOR ALL ENTRIES IN @lt_matnr
    WHERE product                      = @lt_matnr-matnr
      AND fourthsalesspecproductgroup <> ''.

  LOOP AT lt_mvgr4_raw INTO DATA(ls_raw).
    INSERT ls_raw INTO TABLE lt_mvgr4_keys.
  ENDLOOP.

  " NB: lt_mvgr4_txt_raw is declared inline inside this IF, but since
  " inline declarations are visible for the whole enclosing FORM, it
  " remains valid (and simply empty) below even when this branch does
  " not run.
  IF lt_mvgr4_keys IS NOT INITIAL.
    SELECT mvgr4, bezei
      FROM tvm4t
      INTO TABLE @DATA(lt_mvgr4_txt_raw)
      FOR ALL ENTRIES IN @lt_mvgr4_keys
      WHERE spras = 'E'
        AND mvgr4 = @lt_mvgr4_keys-mvgr4.
  ENDIF.

  LOOP AT gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fs_fg>).

    READ TABLE lt_maktx INTO DATA(ls_maktx) WITH KEY matnr = <fs_fg>-matnr.
    IF sy-subrc = 0.
      <fs_fg>-maktx = ls_maktx-maktx.
    ENDIF.

    READ TABLE lt_matkl INTO DATA(ls_matkl) WITH KEY matnr = <fs_fg>-matnr.
    IF sy-subrc = 0.
      <fs_fg>-matkl = ls_matkl-matkl.
    ENDIF.

    READ TABLE lt_mvgr4_raw INTO DATA(ls_mvgr4) WITH KEY matnr = <fs_fg>-matnr.
    IF sy-subrc = 0.
      READ TABLE lt_mvgr4_txt_raw INTO DATA(ls_txt) WITH KEY mvgr4 = ls_mvgr4-mvgr4.
      IF sy-subrc = 0.
        <fs_fg>-mvgr4_txt = ls_txt-bezei.
      ENDIF.
    ENDIF.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CHECK_BATCH_MANAGED_BULK
*&---------------------------------------------------------------------*
* Detailed FS "Unrestricted Stock" / "Quality Stock" — 3 conditions:
*   1) V_MBEW_MD-BWTTY <> '' for Product/Plant  -> batch-managed
*   2) V_MBEW_MD-BWTTY = '' AND
*      I_ProductPlant-IsBatchManagementRequired <> '' -> batch-managed
*   3) V_MBEW_MD-BWTTY = '' AND
*      I_ProductPlant-IsBatchManagementRequired = '' -> not batch-managed
* Classifies every key in one pass (2 bulk SELECTs total) instead of
* up to 2 SELECT SINGLEs per material.
*&---------------------------------------------------------------------*
FORM check_batch_managed_bulk USING    pt_keys          TYPE tt_matnr_werks
                               CHANGING pt_batch_keys    TYPE tt_matnr_werks
                                        pt_nonbatch_keys TYPE tt_matnr_werks.

  CLEAR: pt_batch_keys, pt_nonbatch_keys.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  SELECT matnr, bwkey AS werks, bwtty
    FROM v_mbew_md
    INTO TABLE @DATA(lt_bwtty)
    FOR ALL ENTRIES IN @pt_keys
    WHERE matnr = @pt_keys-matnr
      AND bwkey = @pt_keys-werks.

  SELECT product AS matnr, plant AS werks, isbatchmanagementrequired AS flag
    FROM i_productplant
    INTO TABLE @DATA(lt_batchflag)
    FOR ALL ENTRIES IN @pt_keys
    WHERE product = @pt_keys-matnr
      AND plant   = @pt_keys-werks.

  LOOP AT pt_keys INTO DATA(ls_key).
    DATA(lv_is_batch) = abap_false.

    READ TABLE lt_bwtty INTO DATA(ls_bwtty)
      WITH KEY matnr = ls_key-matnr werks = ls_key-werks.
    IF sy-subrc = 0 AND ls_bwtty-bwtty IS NOT INITIAL.
      lv_is_batch = abap_true.                              "Condition 1
    ELSE.
      READ TABLE lt_batchflag INTO DATA(ls_flag)
        WITH KEY matnr = ls_key-matnr werks = ls_key-werks.
      IF sy-subrc = 0 AND ls_flag-flag IS NOT INITIAL.
        lv_is_batch = abap_true.                            "Condition 2
      ENDIF.                                                  "else Condition 3
    ENDIF.

    IF lv_is_batch = abap_true.
      INSERT ls_key INTO TABLE pt_batch_keys.
    ELSE.
      INSERT ls_key INTO TABLE pt_nonbatch_keys.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_STOCK_BULK
*&---------------------------------------------------------------------*
* Stage B / Stage G shared routine (Total Stock = Unrestricted +
* Quality). Used for the FG candidates AND for every RM/PM component,
* so this is the hottest data volume in the report — computed for an
* arbitrary set of (Material, Plant) keys in a small constant number
* of round trips (2 for batch classification + up to 2 for stock),
* instead of one call, and up to 2 SELECTs, per material.
*&---------------------------------------------------------------------*
FORM get_stock_bulk USING    pt_keys   TYPE tt_matnr_werks
                     CHANGING pt_stock TYPE tt_matnr_werks_qty.

  TYPES: BEGIN OF ty_stock_raw,
           matnr TYPE matnr,
           werks TYPE werks_d,
           lgort TYPE lgort_d,
           qty   TYPE menge_d,
         END OF ty_stock_raw.

  " Explicit DATA: for the same reason as GET_MATERIAL_MASTER_DATA_BULK
  " — this table is built via repeated APPENDING SELECTs, so it needs a
  " concrete, named type rather than an inline VALUE literal.
  DATA: lt_stock_raw TYPE STANDARD TABLE OF ty_stock_raw WITH EMPTY KEY.

  CLEAR pt_stock.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  DATA(lt_batch_keys)    = VALUE tt_matnr_werks( ).
  DATA(lt_nonbatch_keys) = VALUE tt_matnr_werks( ).
  PERFORM check_batch_managed_bulk USING pt_keys
                                    CHANGING lt_batch_keys lt_nonbatch_keys.

  IF lt_batch_keys IS NOT INITIAL.
    " Batch-managed: NSDM_V_MCHB, CLABS (unrestricted) + CINSM (quality)
    SELECT matnr, werks, lgort, ( clabs + cinsm ) AS qty
      FROM nsdm_v_mchb
      APPENDING TABLE @lt_stock_raw
      FOR ALL ENTRIES IN @lt_batch_keys
      WHERE matnr = @lt_batch_keys-matnr
        AND werks = @lt_batch_keys-werks
        AND ( clabs <> 0 OR cinsm <> 0 ).
  ENDIF.

  IF lt_nonbatch_keys IS NOT INITIAL.
    " Not batch-managed: NSDM_V_MARD, LABST (unrestricted) + INSME (quality)
    SELECT matnr, werks, lgort, ( labst + insme ) AS qty
      FROM nsdm_v_mard
      APPENDING TABLE @lt_stock_raw
      FOR ALL ENTRIES IN @lt_nonbatch_keys
      WHERE matnr = @lt_nonbatch_keys-matnr
        AND werks = @lt_nonbatch_keys-werks
        AND ( labst <> 0 OR insme <> 0 ).
  ENDIF.

  " Exclude storage locations listed in ZPP_PLAN_SLOC, sum the rest per
  " Material/Plant — in-memory only, no DB access.
  LOOP AT lt_stock_raw INTO DATA(ls_raw).
    READ TABLE gt_sloc_excl TRANSPORTING NO FIELDS
      WITH KEY werks = ls_raw-werks
               lgort = ls_raw-lgort
      BINARY SEARCH.
    IF sy-subrc <> 0.
      READ TABLE pt_stock ASSIGNING FIELD-SYMBOL(<ls_stock>)
        WITH TABLE KEY matnr = ls_raw-matnr werks = ls_raw-werks.
      IF sy-subrc = 0.
        <ls_stock>-qty = <ls_stock>-qty + ls_raw-qty.
      ELSE.
        INSERT VALUE #( matnr = ls_raw-matnr werks = ls_raw-werks qty = ls_raw-qty )
          INTO TABLE pt_stock.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_B_GET_FG_STOCK
*&---------------------------------------------------------------------*
* Stage B — FG stock for every FG candidate at once.
*&---------------------------------------------------------------------*
FORM stage_b_get_fg_stock.

  DATA(lt_keys) = VALUE tt_matnr_werks( ).
  LOOP AT gt_fg_candidates INTO DATA(ls_fg).
    INSERT VALUE ty_matnr_werks( matnr = ls_fg-matnr werks = ls_fg-werks ) INTO TABLE lt_keys.
  ENDLOOP.

  DATA(lt_stock) = VALUE tt_matnr_werks_qty( ).
  PERFORM get_stock_bulk USING lt_keys CHANGING lt_stock.

  LOOP AT gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fg>).
    READ TABLE lt_stock INTO DATA(ls_stock)
      WITH TABLE KEY matnr = <fg>-matnr werks = <fg>-werks.
    IF sy-subrc = 0.
      <fg>-fg_stock = ls_stock-qty.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_C_GET_TOTAL_SO_QTY
*&---------------------------------------------------------------------*
* Stage C — Total Sales Order, per Detailed FS "Total Sales Order" row,
* for every FG candidate at once. Reuses the raw SO item set gathered
* in Stage A. Two bulk selects for the WHOLE selection (SO validity,
* delivered qty), then one in-memory pass to aggregate per Material/
* Plant — instead of 2 round trips per open SO line.
* See header, open item 6, on the "=A and B" clause that could not be
* implemented because the FS text does not name a field.
*&---------------------------------------------------------------------*
FORM stage_c_get_total_so_qty.

  DATA: lt_docnrs TYPE STANDARD TABLE OF vbeln WITH EMPTY KEY.

  IF gt_so_items_raw IS INITIAL.
    RETURN.
  ENDIF.

  " Only consider SOs with OverallSDProcessStatus = 'B' and
  " OverallDeliveryBlockStatus <> 'C' — one bulk lookup for the whole
  " selection instead of a SELECT SINGLE per SO line.
  LOOP AT gt_so_items_raw INTO DATA(ls_so).
    APPEND ls_so-salesdocument TO lt_docnrs.
  ENDLOOP.
  SORT lt_docnrs.
  DELETE ADJACENT DUPLICATES FROM lt_docnrs.

  SELECT salesdocument
    FROM i_salesdocument
    INTO TABLE @DATA(lt_valid_so)
    FOR ALL ENTRIES IN @lt_docnrs
    WHERE salesdocument              = @lt_docnrs-table_line
      AND overallsdprocessstatus     = 'B'
      AND overalldeliveryblockstatus <> 'C'.

  " Delivered qty for every open SO line in the selection, in one
  " grouped bulk select.
  SELECT referencesddocument     AS salesdocument,
         referencesddocumentitem AS salesdocumentitem,
         SUM( actualdeliveryquantity ) AS qty
    FROM i_deliverydocumentitem
    INTO TABLE @DATA(lt_deliv_sum)
    FOR ALL ENTRIES IN @gt_so_items_raw
    WHERE referencesddocument     = @gt_so_items_raw-salesdocument
      AND referencesddocumentitem = @gt_so_items_raw-salesdocumentitem
      AND goodsmovementstatus    <> 'C'
    GROUP BY referencesddocument, referencesddocumentitem.

  DATA(lt_so_qty) = VALUE tt_matnr_werks_qty( ).

  LOOP AT gt_so_items_raw INTO ls_so.
    READ TABLE lt_valid_so TRANSPORTING NO FIELDS
      WITH KEY table_line = ls_so-salesdocument
      BINARY SEARCH.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    DATA(lv_delivered) = VALUE menge_d( ).
    READ TABLE lt_deliv_sum INTO DATA(ls_deliv)
      WITH KEY salesdocument     = ls_so-salesdocument
               salesdocumentitem = ls_so-salesdocumentitem.
    IF sy-subrc = 0.
      lv_delivered = ls_deliv-qty.
    ENDIF.

    DATA(lv_qty) = ls_so-orderquantity - lv_delivered.

    READ TABLE lt_so_qty ASSIGNING FIELD-SYMBOL(<ls_sq>)
      WITH TABLE KEY matnr = ls_so-matnr werks = ls_so-werks.
    IF sy-subrc = 0.
      <ls_sq>-qty = <ls_sq>-qty + lv_qty.
    ELSE.
      INSERT VALUE #( matnr = ls_so-matnr werks = ls_so-werks qty = lv_qty )
        INTO TABLE lt_so_qty.
    ENDIF.
  ENDLOOP.

  LOOP AT gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fg>).
    READ TABLE lt_so_qty INTO DATA(ls_sum)
      WITH TABLE KEY matnr = <fg>-matnr werks = <fg>-werks.
    IF sy-subrc = 0.
      <fg>-tot_so_qty = ls_sum-qty.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_D_GET_NET_TOTAL_STO_QTY
*&---------------------------------------------------------------------*
* Stage D — Net Total STO, per Detailed FS "Net Total STO" row, for
* every FG candidate at once. Aggregate-level: SUM(OrderQuantity) -
* SUM(ActualDeliveryQuantity), grouped by Material/Plant — see header,
* open item 4 on the status filter combination, and open item 7 on the
* Material vs. ManufacturerMaterial field used to match the FG. Two
* bulk selects for the WHOLE selection instead of 1-2 round trips per
* FG candidate.
*&---------------------------------------------------------------------*
FORM stage_d_get_net_total_sto_qty.

  DATA(lt_keys) = VALUE tt_matnr_werks( ).
  LOOP AT gt_fg_candidates INTO DATA(ls_fg).
    INSERT VALUE ty_matnr_werks( matnr = ls_fg-matnr werks = ls_fg-werks ) INTO TABLE lt_keys.
  ENDLOOP.

  IF lt_keys IS INITIAL.
    RETURN.
  ENDIF.

  SELECT poi~purchaseorder, poi~purchaseorderitem,
         poi~material AS matnr, po~supplyingplant AS werks,
         poi~orderquantity
    FROM i_purchaseorderitem AS poi
    INNER JOIN i_purchaseorder AS po
      ON po~purchaseorder = poi~purchaseorder
    INTO TABLE @DATA(lt_po_items)
    FOR ALL ENTRIES IN @lt_keys
    WHERE po~supplyingplant                = @lt_keys-werks
      AND poi~material                      = @lt_keys-matnr
      AND po~purchaseordertype              IN ( 'ZUB', 'UB', 'ZSTR', 'ZOST', 'ZBST',
                                                   'ZUB1', 'ZUB2', 'ZUB3', 'ZUB4',
                                                   'ZUB5', 'ZUB6', 'ZUB7', 'ZUB8' )
      AND po~purchasingdocumentdeletioncode = ''
      AND poi~purchaseordercategory         = 'F'
      AND poi~materialtype                  = 'FERT'
      AND poi~iscompletelydelivered         = ''.

  IF lt_po_items IS INITIAL.
    RETURN.
  ENDIF.

  SELECT purchaseorder, purchaseorderitem,
         SUM( actualdeliveryquantity ) AS qty
    FROM i_deliverydocumentitem
    INTO TABLE @DATA(lt_po_deliv)
    FOR ALL ENTRIES IN @lt_po_items
    WHERE purchaseorder     = @lt_po_items-purchaseorder
      AND purchaseorderitem = @lt_po_items-purchaseorderitem
      AND goodsmovementstatus = 'C'
      AND sdprocessstatus     IN ( 'A', 'B' )
    GROUP BY purchaseorder, purchaseorderitem.

  DATA(lt_sto_qty) = VALUE tt_matnr_werks_qty( ).

  LOOP AT lt_po_items INTO DATA(ls_po).
    DATA(lv_deliv) = VALUE menge_d( ).
    READ TABLE lt_po_deliv INTO DATA(ls_deliv)
      WITH KEY purchaseorder     = ls_po-purchaseorder
               purchaseorderitem = ls_po-purchaseorderitem.
    IF sy-subrc = 0.
      lv_deliv = ls_deliv-qty.
    ENDIF.

    DATA(lv_net) = ls_po-orderquantity - lv_deliv.

    READ TABLE lt_sto_qty ASSIGNING FIELD-SYMBOL(<ls_sq>)
      WITH TABLE KEY matnr = ls_po-matnr werks = ls_po-werks.
    IF sy-subrc = 0.
      <ls_sq>-qty = <ls_sq>-qty + lv_net.
    ELSE.
      INSERT VALUE #( matnr = ls_po-matnr werks = ls_po-werks qty = lv_net )
        INTO TABLE lt_sto_qty.
    ENDIF.
  ENDLOOP.

  LOOP AT gt_fg_candidates ASSIGNING FIELD-SYMBOL(<fg>).
    READ TABLE lt_sto_qty INTO DATA(ls_sum)
      WITH TABLE KEY matnr = <fg>-matnr werks = <fg>-werks.
    IF sy-subrc = 0.
      <fg>-net_sto_qty = ls_sum-qty.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_ACTIVE_BOM_ALTERNATIVES_BULK
*&---------------------------------------------------------------------*
* Detailed FS "Alternative" row:
*   I_BillOfMaterialItemTp-Product/Plant -> distinct BillOfMaterial +
*   BillOfMaterialVariant. Filter via I_BillOfMaterial where
*   BOMIsArchivedForDeletion = '' and BillOfMaterialStatus = '1'.
* No tie-breaker stated if multiple remain — see header, open item 3.
* Resolved for every deficit FG at once (2 bulk selects total) instead
* of 2 SELECTs per FG.
*&---------------------------------------------------------------------*
FORM get_active_bom_alternatives_bulk USING    pt_keys TYPE tt_matnr_werks
                                       CHANGING pt_alt  TYPE tt_matnr_werks_stlal.

  TYPES: BEGIN OF ty_bom_item,
           matnr                 TYPE matnr,
           werks                 TYPE werks_d,
           billofmaterial        TYPE cs_stlnr,
           billofmaterialvariant TYPE stlal,
         END OF ty_bom_item.
  TYPES: BEGIN OF ty_bom_hdr,
           billofmaterial        TYPE cs_stlnr,
           billofmaterialvariant TYPE stlal,
         END OF ty_bom_hdr.

  " Ad-hoc keyed/typed work tables built via LOOP+INSERT/APPEND need
  " explicit named types — see the note in GET_MATERIAL_MASTER_DATA_BULK.
  DATA: lt_bom_hdr_keys   TYPE SORTED TABLE OF ty_bom_hdr
                              WITH UNIQUE KEY billofmaterial billofmaterialvariant,
        lt_bom_candidates TYPE STANDARD TABLE OF ty_bom_item WITH EMPTY KEY.

  CLEAR pt_alt.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  SELECT DISTINCT material AS matnr, plant AS werks,
                  billofmaterial, billofmaterialvariant
    FROM i_billofmaterialitemtp
    INTO TABLE @DATA(lt_bom_items)
    FOR ALL ENTRIES IN @pt_keys
    WHERE material = @pt_keys-matnr
      AND plant    = @pt_keys-werks.

  IF lt_bom_items IS INITIAL.
    RETURN.
  ENDIF.

  LOOP AT lt_bom_items INTO DATA(ls_item).
    INSERT VALUE #( billofmaterial        = ls_item-billofmaterial
                     billofmaterialvariant = ls_item-billofmaterialvariant )
      INTO TABLE lt_bom_hdr_keys.
  ENDLOOP.

  SELECT bom~billofmaterial, bom~billofmaterialvariant
    FROM i_billofmaterial AS bom
    INTO TABLE @DATA(lt_bom_active)
    FOR ALL ENTRIES IN @lt_bom_hdr_keys
    WHERE bom~billofmaterial        = @lt_bom_hdr_keys-billofmaterial
      AND bom~billofmaterialvariant = @lt_bom_hdr_keys-billofmaterialvariant
      AND bom~bomisarchivedfordeletion = ''
      AND bom~billofmaterialstatus     = '1'.

  IF lt_bom_active IS INITIAL.
    RETURN.
  ENDIF.

  SORT lt_bom_active BY billofmaterial billofmaterialvariant.

  " Keep only BOM item combos whose header is active/non-archived.
  LOOP AT lt_bom_items INTO ls_item.
    READ TABLE lt_bom_active TRANSPORTING NO FIELDS
      WITH KEY billofmaterial        = ls_item-billofmaterial
               billofmaterialvariant = ls_item-billofmaterialvariant
      BINARY SEARCH.
    IF sy-subrc = 0.
      APPEND ls_item TO lt_bom_candidates.
    ENDIF.
  ENDLOOP.

  " ASSUMPTION (open item 3): lowest variant wins when several active
  " alternatives exist, per FG. Confirm with Mukesh.
  SORT lt_bom_candidates BY matnr werks billofmaterialvariant ASCENDING.
  DELETE ADJACENT DUPLICATES FROM lt_bom_candidates COMPARING matnr werks.

  LOOP AT lt_bom_candidates INTO ls_item.
    INSERT VALUE #( matnr = ls_item-matnr werks = ls_item-werks
                     stlal = ls_item-billofmaterialvariant )
      INTO TABLE pt_alt.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_F_BOM_EXPLOSION_ALL
*&---------------------------------------------------------------------*
* Stage F — BOM alternative lookup is bulked (one call for all deficit
* FGs). The actual explosion via CS_BOM_EXPL_MAT_V2 (RCS11001's
* underlying FM) still runs once per deficit FG: it is a function
* module, not a raw SELECT, and the FS explicitly requires per-material
* explosion ("at a time one BOM will be considered"), so this cannot be
* turned into a single bulk call. The loop below contains no SELECT
* statements, only the FM call.
*&---------------------------------------------------------------------*
FORM stage_f_bom_explosion_all.

  CLEAR gt_bom_comp.

  DATA(lt_deficit_keys) = VALUE tt_matnr_werks( ).
  LOOP AT gt_fg_candidates INTO DATA(ls_fg) WHERE deficit_fg < 0.
    INSERT VALUE ty_matnr_werks( matnr = ls_fg-matnr werks = ls_fg-werks ) INTO TABLE lt_deficit_keys.
  ENDLOOP.

  IF lt_deficit_keys IS INITIAL.
    RETURN.
  ENDIF.

  DATA(lt_alt) = VALUE tt_matnr_werks_stlal( ).
  PERFORM get_active_bom_alternatives_bulk USING lt_deficit_keys CHANGING lt_alt.

  LOOP AT gt_fg_candidates INTO ls_fg WHERE deficit_fg < 0.
    READ TABLE lt_alt INTO DATA(ls_alt)
      WITH TABLE KEY matnr = ls_fg-matnr werks = ls_fg-werks.
    IF sy-subrc <> 0.
      CONTINUE.  "no active, non-archived BOM found — nothing to explode
    ENDIF.

    PERFORM explode_bom USING ls_fg ls_alt-stlal CHANGING gt_bom_comp.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  EXPLODE_BOM
*&---------------------------------------------------------------------*
* Single-FG BOM explosion via CS_BOM_EXPL_MAT_V2, explosion level 1
* only. See STAGE_F_BOM_EXPLOSION_ALL for why this stays per-FG. STB
* and MATCAT must stay classic typed tables — they're TABLES
* parameters of a classic function module, which requires concrete
* named types (no inline declaration possible there).
*&---------------------------------------------------------------------*
FORM explode_bom USING    pu_fg       TYPE ty_fg_deficit
                           pu_stlal    TYPE stlal
                  CHANGING pc_bom_comp TYPE tt_bom_comp.

  DATA: lt_stb    TYPE STANDARD TABLE OF stpox,
        lt_matcat TYPE STANDARD TABLE OF cscmat.

  CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
    EXPORTING
      capid                 = 'PP01'
      bmeng                 = abs( pu_fg-deficit_fg )   "Required Qty = Deficit Qty
      datuv                 = sy-datum                  "Valid On = System Date
      mehrs                 = 'X'
      mtnrv                 = pu_fg-matnr
      stlal                 = pu_stlal
      stlan                 = '1'                        "BOM Usage = 1
      werks                 = pu_fg-werks
    TABLES
      stb                   = lt_stb
      matcat                = lt_matcat
    EXCEPTIONS
      alt_not_found         = 1
      call_invalid          = 2
      material_not_found    = 3
      missing_authorization = 4
      no_bom_found          = 5
      no_plant_data         = 6
      no_suitable_bom_found = 7
      conversion_error      = 8
      OTHERS                = 9.

  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  LOOP AT lt_stb INTO DATA(ls_stb) WHERE dumps <> 'X'.
    APPEND INITIAL LINE TO pc_bom_comp ASSIGNING FIELD-SYMBOL(<fs_comp>).
    <fs_comp>-fg    = pu_fg.
    <fs_comp>-idnrk = ls_stb-idnrk.
    <fs_comp>-menge = ls_stb-mngko.   "QTY as per BOM
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_MINMAX_STOCK_BULK
*&---------------------------------------------------------------------*
* Min/Max Stock Level — I_ProductSupplyPlanning, for an arbitrary set
* of (Material, Plant) keys in one round trip.
*&---------------------------------------------------------------------*
FORM get_minmax_stock_bulk USING    pt_keys   TYPE tt_matnr_werks
                           CHANGING pt_minmax TYPE tt_minmax_result.

  CLEAR pt_minmax.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  SELECT product AS matnr, plant AS werks,
         reorderthresholdquantity AS min_stock,
         maximumstockquantity     AS max_stock
    FROM i_productsupplyplanning
    INTO TABLE @pt_minmax
    FOR ALL ENTRIES IN @pt_keys
    WHERE product = @pt_keys-matnr
      AND plant   = @pt_keys-werks.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_NET_WEIGHT_BULK
*&---------------------------------------------------------------------*
* Net Weight — I_Product-NetWeight, for every distinct component
* material in one round trip (not plant-specific).
*&---------------------------------------------------------------------*
FORM get_net_weight_bulk USING    pt_keys      TYPE tt_matnr_werks
                         CHANGING pt_netweight TYPE tt_netweight_result.

  TYPES: BEGIN OF ty_matnr_key,
           matnr TYPE matnr,
         END OF ty_matnr_key.

  DATA: lt_matnr TYPE SORTED TABLE OF ty_matnr_key WITH UNIQUE KEY matnr.

  CLEAR pt_netweight.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  LOOP AT pt_keys INTO DATA(ls_key).
    INSERT VALUE ty_matnr_key( matnr = ls_key-matnr ) INTO TABLE lt_matnr.
  ENDLOOP.

  SELECT product AS matnr, netweight AS net_weight
    FROM i_product
    INTO TABLE @pt_netweight
    FOR ALL ENTRIES IN @lt_matnr
    WHERE product = @lt_matnr-matnr.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_WORKCENTER_PRT_BULK
*&---------------------------------------------------------------------*
* Per Detailed FS "Work Center" / "PRT" rows — table names unchanged
* from the original spec:
*   Work Center: MAPL(PLNTY=N/2) -> PLNNR,PLNAL
*                -> PLKO(PLNTY=N/2, LOEKZ='') validity check
*                -> PLAS(PLNNR,PLNAL) -> PLNNR,ZAEHL
*                -> PLPO(PLNNR,ZAEHL) -> ARBID
*                -> CRHD(OBJID=ARBID) -> ARBPL
*   PRT:         MAPL(PLNTY=N) -> PLNNR,PLNAL
*                -> PLKO(PLNTY=N, LOEKZ='')
*                -> PLFH(PLNNR,PLNAL, LOEKZ='') -> OBJID
*                -> CRVE_A(OBJID, OBJTY='FH') -> EQUNR
* Both chains resolved for an arbitrary set of (Material, Plant) keys
* at once: each hop is one bulk SELECT (with the "1st routing"/"1st
* PLAS line" tie-break applied via SORT + DELETE ADJACENT DUPLICATES,
* same lowest-value-wins rule as the BOM alternative — see header,
* open item 3), then the hops are chained back together in memory.
*&---------------------------------------------------------------------*
FORM get_workcenter_prt_bulk USING    pt_keys TYPE tt_matnr_werks
                             CHANGING pt_wc   TYPE tt_wc_result
                                      pt_prt  TYPE tt_prt_result.

  TYPES: BEGIN OF ty_plnnr_plnal,
           plnnr TYPE plnnr,
           plnal TYPE plnal,
         END OF ty_plnnr_plnal.
  TYPES: BEGIN OF ty_plnnr_zaehl,
           plnnr TYPE plnnr,
           zaehl TYPE cim_count,
         END OF ty_plnnr_zaehl.
  TYPES: BEGIN OF ty_arbid_key,
           arbid TYPE arbid,
         END OF ty_arbid_key.
  TYPES: BEGIN OF ty_objid_key,
           objid TYPE cr_objid,
         END OF ty_objid_key.

  " Ad-hoc keyed work tables built via LOOP+INSERT need explicit named
  " types — see the note in GET_MATERIAL_MASTER_DATA_BULK.
  DATA: lt_plas_keys TYPE SORTED TABLE OF ty_plnnr_plnal WITH UNIQUE KEY plnnr plnal,
        lt_plpo_keys TYPE SORTED TABLE OF ty_plnnr_zaehl WITH UNIQUE KEY plnnr zaehl,
        lt_crhd_keys TYPE SORTED TABLE OF ty_arbid_key   WITH UNIQUE KEY arbid,
        lt_crve_keys TYPE SORTED TABLE OF ty_objid_key   WITH UNIQUE KEY objid.

  CLEAR: pt_wc, pt_prt.

  IF pt_keys IS INITIAL.
    RETURN.
  ENDIF.

  "===== Work Center chain: PLNTY IN ('N','2') =====
  SELECT mapl~matnr, mapl~werks, mapl~plnnr, mapl~plnal
    FROM mapl
    INNER JOIN plko
      ON plko~plnty = mapl~plnty
     AND plko~plnnr = mapl~plnnr
     AND plko~loekz = ''
    INTO TABLE @DATA(lt_wc_routing)
    FOR ALL ENTRIES IN @pt_keys
    WHERE mapl~matnr = @pt_keys-matnr
      AND mapl~werks = @pt_keys-werks
      AND mapl~plnty IN ( 'N', '2' ).

  " 1st routing per Material/Plant.
  SORT lt_wc_routing BY matnr werks plnnr ASCENDING.
  DATA(lt_wc_first) = lt_wc_routing.
  DELETE ADJACENT DUPLICATES FROM lt_wc_first COMPARING matnr werks.

  IF lt_wc_first IS NOT INITIAL.

    LOOP AT lt_wc_first INTO DATA(ls_wcf).
      INSERT VALUE #( plnnr = ls_wcf-plnnr plnal = ls_wcf-plnal ) INTO TABLE lt_plas_keys.
    ENDLOOP.

    SELECT plnnr, plnal, zaehl
      FROM plas
      INTO TABLE @DATA(lt_plas)
      FOR ALL ENTRIES IN @lt_plas_keys
      WHERE plnnr = @lt_plas_keys-plnnr
        AND plnal = @lt_plas_keys-plnal.

    SORT lt_plas BY plnnr plnal zaehl ASCENDING.
    DATA(lt_plas_first) = lt_plas.
    DELETE ADJACENT DUPLICATES FROM lt_plas_first COMPARING plnnr plnal.

    IF lt_plas_first IS NOT INITIAL.

      LOOP AT lt_plas_first INTO DATA(ls_plasf).
        INSERT VALUE #( plnnr = ls_plasf-plnnr zaehl = ls_plasf-zaehl ) INTO TABLE lt_plpo_keys.
      ENDLOOP.

      SELECT plnnr, zaehl, arbid
        FROM plpo
        INTO TABLE @DATA(lt_plpo)
        FOR ALL ENTRIES IN @lt_plpo_keys
        WHERE plnnr = @lt_plpo_keys-plnnr
          AND zaehl = @lt_plpo_keys-zaehl.

      LOOP AT lt_plpo INTO DATA(ls_plpo) WHERE arbid IS NOT INITIAL.
        INSERT VALUE #( arbid = ls_plpo-arbid ) INTO TABLE lt_crhd_keys.
      ENDLOOP.

      IF lt_crhd_keys IS NOT INITIAL.
        SELECT objid AS arbid, arbpl
          FROM crhd
          INTO TABLE @DATA(lt_crhd)
          FOR ALL ENTRIES IN @lt_crhd_keys
          WHERE objid = @lt_crhd_keys-arbid.
      ENDIF.
    ENDIF.
  ENDIF.

  " Chain the hops back together: Material/Plant -> routing -> PLAS ->
  " PLPO -> Work Center. In-memory only, no DB access. LT_PLAS_FIRST/
  " LT_PLPO/LT_CRHD stay valid (simply empty) here even if the IF
  " blocks above never ran, since inline declarations are visible for
  " the whole enclosing FORM.
  LOOP AT lt_wc_first INTO ls_wcf.
    READ TABLE lt_plas_first INTO ls_plasf
      WITH KEY plnnr = ls_wcf-plnnr plnal = ls_wcf-plnal.
    CHECK sy-subrc = 0.

    READ TABLE lt_plpo INTO ls_plpo
      WITH KEY plnnr = ls_plasf-plnnr zaehl = ls_plasf-zaehl.
    CHECK sy-subrc = 0 AND ls_plpo-arbid IS NOT INITIAL.

    READ TABLE lt_crhd INTO DATA(ls_crhd)
      WITH KEY arbid = ls_plpo-arbid.
    CHECK sy-subrc = 0.

    INSERT VALUE #( matnr = ls_wcf-matnr werks = ls_wcf-werks arbpl = ls_crhd-arbpl )
      INTO TABLE pt_wc.
  ENDLOOP.

  "===== PRT chain: PLNTY = 'N' only =====
  SELECT mapl~matnr, mapl~werks, mapl~plnnr, mapl~plnal
    FROM mapl
    INNER JOIN plko
      ON plko~plnty = mapl~plnty
     AND plko~plnnr = mapl~plnnr
     AND plko~loekz = ''
    INTO TABLE @DATA(lt_prt_routing)
    FOR ALL ENTRIES IN @pt_keys
    WHERE mapl~matnr = @pt_keys-matnr
      AND mapl~werks = @pt_keys-werks
      AND mapl~plnty = 'N'.

  SORT lt_prt_routing BY matnr werks plnnr ASCENDING.
  DATA(lt_prt_first) = lt_prt_routing.
  DELETE ADJACENT DUPLICATES FROM lt_prt_first COMPARING matnr werks.

  IF lt_prt_first IS NOT INITIAL.

    SELECT plnnr, plnal, objid
      FROM plfh
      INTO TABLE @DATA(lt_plfh)
      FOR ALL ENTRIES IN @lt_prt_first
      WHERE plnnr = @lt_prt_first-plnnr
        AND plnal = @lt_prt_first-plnal
        AND loekz = ''.

    LOOP AT lt_plfh INTO DATA(ls_plfh) WHERE objid IS NOT INITIAL.
      INSERT VALUE #( objid = ls_plfh-objid ) INTO TABLE lt_crve_keys.
    ENDLOOP.

    IF lt_crve_keys IS NOT INITIAL.
      SELECT objid, equnr
        FROM crve_a
        INTO TABLE @DATA(lt_crve)
        FOR ALL ENTRIES IN @lt_crve_keys
        WHERE objid = @lt_crve_keys-objid
          AND objty = 'FH'.
    ENDIF.
  ENDIF.

  LOOP AT lt_prt_first INTO DATA(ls_prtf).
    READ TABLE lt_plfh INTO ls_plfh
      WITH KEY plnnr = ls_prtf-plnnr plnal = ls_prtf-plnal.
    CHECK sy-subrc = 0 AND ls_plfh-objid IS NOT INITIAL.

    READ TABLE lt_crve INTO DATA(ls_crve)
      WITH KEY objid = ls_plfh-objid.
    CHECK sy-subrc = 0.

    INSERT VALUE #( matnr = ls_prtf-matnr werks = ls_prtf-werks equnr = ls_crve-equnr )
      INTO TABLE pt_prt.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  STAGE_G_PROCESS_COMPONENTS_BULK
*&---------------------------------------------------------------------*
* Stage G — every BOM component across every deficit FG, enriched in
* one bulk pass: stock, Min/Max stock, Net Weight, Work Center/PRT are
* each fetched once for the whole component set, then the final
* assembly LOOP below does pure in-memory table reads — no SELECT
* statements inside it at all.
*&---------------------------------------------------------------------*
FORM stage_g_process_components_bulk.

  IF gt_bom_comp IS INITIAL.
    RETURN.
  ENDIF.

  DATA(lt_keys) = VALUE tt_matnr_werks( ).
  LOOP AT gt_bom_comp INTO DATA(ls_bom).
    INSERT VALUE ty_matnr_werks( matnr = ls_bom-idnrk werks = ls_bom-fg-werks )
      INTO TABLE lt_keys.
  ENDLOOP.

  DATA(lt_stock)     = VALUE tt_matnr_werks_qty( ).
  DATA(lt_minmax)    = VALUE tt_minmax_result( ).
  DATA(lt_netweight) = VALUE tt_netweight_result( ).
  DATA(lt_wc)        = VALUE tt_wc_result( ).
  DATA(lt_prt)       = VALUE tt_prt_result( ).

  PERFORM get_stock_bulk          USING lt_keys CHANGING lt_stock.
  PERFORM get_minmax_stock_bulk   USING lt_keys CHANGING lt_minmax.
  PERFORM get_net_weight_bulk     USING lt_keys CHANGING lt_netweight.
  PERFORM get_workcenter_prt_bulk USING lt_keys CHANGING lt_wc lt_prt.

  LOOP AT gt_bom_comp INTO ls_bom.

    APPEND INITIAL LINE TO gt_alv_out ASSIGNING FIELD-SYMBOL(<alv>).

    <alv>-fg      = ls_bom-fg.
    <alv>-idnrk   = ls_bom-idnrk.
    <alv>-qty_bom = ls_bom-menge.

    READ TABLE lt_stock INTO DATA(ls_stock)
      WITH TABLE KEY matnr = ls_bom-idnrk werks = ls_bom-fg-werks.
    IF sy-subrc = 0.
      <alv>-rmpm_stock = ls_stock-qty.
    ENDIF.

    " Deficit = Requirement Qty - Total Stock
    <alv>-rmpm_deficit = ls_bom-menge - <alv>-rmpm_stock.

    READ TABLE lt_minmax INTO DATA(ls_minmax)
      WITH TABLE KEY matnr = ls_bom-idnrk werks = ls_bom-fg-werks.
    IF sy-subrc = 0.
      <alv>-min_stock = ls_minmax-min_stock.
      <alv>-max_stock = ls_minmax-max_stock.
    ENDIF.

    READ TABLE lt_netweight INTO DATA(ls_netweight)
      WITH TABLE KEY matnr = ls_bom-idnrk.
    IF sy-subrc = 0.
      <alv>-net_weight = ls_netweight-net_weight.
    ENDIF.

    READ TABLE lt_wc INTO DATA(ls_wc)
      WITH TABLE KEY matnr = ls_bom-idnrk werks = ls_bom-fg-werks.
    IF sy-subrc = 0.
      <alv>-arbpl = ls_wc-arbpl.
    ENDIF.

    READ TABLE lt_prt INTO DATA(ls_prt)
      WITH TABLE KEY matnr = ls_bom-idnrk werks = ls_bom-fg-werks.
    IF sy-subrc = 0.
      <alv>-equnr = ls_prt-equnr.
    ENDIF.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
* ALV column order per BRD "ALV generation format" row.
*&---------------------------------------------------------------------*
FORM display_alv.

  IF gt_alv_out IS INITIAL.
    MESSAGE 'No FG deficits found for the selection.' TYPE 'S' DISPLAY LIKE 'W'.
    RETURN.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = DATA(lo_alv)
        CHANGING  t_table      = gt_alv_out ).
    CATCH cx_salv_msg INTO DATA(lx_msg).
      MESSAGE lx_msg->get_text( ) TYPE 'E'.
      RETURN.
  ENDTRY.

  lo_alv->get_functions( )->set_all( abap_true ).
  DATA(lo_cols) = lo_alv->get_columns( ).
  lo_cols->set_optimize( abap_true ).

  " NB: GET_COLUMN returns the CL_SALV_COLUMN base reference; narrowed
  " to CL_SALV_COLUMN_TABLE via '?=' before SET_MEDIUM_TEXT, same as
  " the original code — kept as-is rather than guessed away.
  DATA: lo_column TYPE REF TO cl_salv_column_table.

  TRY.
      lo_column ?= lo_cols->get_column( 'MATNR' ).
      lo_column->set_medium_text( 'Material' ).

      lo_column ?= lo_cols->get_column( 'MAKTX' ).
      lo_column->set_medium_text( 'Material Description' ).

      lo_column ?= lo_cols->get_column( 'MATKL' ).
      lo_column->set_medium_text( 'Material Group' ).

      lo_column ?= lo_cols->get_column( 'MVGR4_TXT' ).
      lo_column->set_medium_text( 'Material Category' ).

      lo_column ?= lo_cols->get_column( 'WERKS' ).
      lo_column->set_medium_text( 'Plant' ).

      lo_column ?= lo_cols->get_column( 'FG_STOCK' ).
      lo_column->set_medium_text( 'FG Stock' ).

      lo_column ?= lo_cols->get_column( 'TOT_SO_QTY' ).
      lo_column->set_medium_text( 'Total Sales Order' ).

      lo_column ?= lo_cols->get_column( 'NET_STO_QTY' ).
      lo_column->set_medium_text( 'Net Total STO' ).

      lo_column ?= lo_cols->get_column( 'DEFICIT_FG' ).
      lo_column->set_medium_text( 'Deficit/Surplus FG' ).

      lo_column ?= lo_cols->get_column( 'IDNRK' ).
      lo_column->set_medium_text( 'BOM Component' ).

      lo_column ?= lo_cols->get_column( 'QTY_BOM' ).
      lo_column->set_medium_text( 'QTY as per BOM' ).

      lo_column ?= lo_cols->get_column( 'RMPM_STOCK' ).
      lo_column->set_medium_text( 'RM/PM Stock' ).

      lo_column ?= lo_cols->get_column( 'RMPM_DEFICIT' ).
      lo_column->set_medium_text( 'RM/PM Deficit' ).

      lo_column ?= lo_cols->get_column( 'MIN_STOCK' ).
      lo_column->set_medium_text( 'Min Stock Level' ).

      lo_column ?= lo_cols->get_column( 'MAX_STOCK' ).
      lo_column->set_medium_text( 'Max Stock Level' ).

      lo_column ?= lo_cols->get_column( 'NET_WEIGHT' ).
      lo_column->set_medium_text( 'Net Weight' ).

      lo_column ?= lo_cols->get_column( 'ARBPL' ).
      lo_column->set_medium_text( 'Work Center' ).

      lo_column ?= lo_cols->get_column( 'EQUNR' ).
      lo_column->set_medium_text( 'PRT' ).
    CATCH cx_salv_not_found.
      "column not present — ignore
  ENDTRY.

  lo_alv->display( ).

ENDFORM.
